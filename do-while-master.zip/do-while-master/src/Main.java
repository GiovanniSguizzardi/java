import javax.swing.*;
import java.util.Scanner;
public class Main {

    public static void main(String[] args){

        //Lista de produtos
        Produto produto;
        boolean encerrar = false;
        String nome = "";
        double valor = 0;
        double total = 0;
        int quantidade = 0;

        do {
            nome = JOptionPane.showInputDialog("Nome do produto:");
            valor = Double.parseDouble(JOptionPane.showInputDialog("Valor do produto [APENAS NUMEROS]:"));
            quantidade = Integer.parseInt(JOptionPane.showInputDialog("Quantidade comprada [APENAS NUMEROS]:"));

            produto = new Produto(nome, valor * quantidade);
            System.out.println(produto);

            total = total + produto.getValor();

            int opcao = Integer.parseInt(
                    JOptionPane.showInputDialog("Deseja mais alguma coisa?" + " [ 1 ] Sim " + "[ 0 ] Nao"));

                    encerrar = opcao == 1 ? false:true;

        }while (encerrar == false);

        System.out.println("Total da compra: R$" + total);
        System.out.println("Produtos comprados na sua lista: " + nome);

    }
}