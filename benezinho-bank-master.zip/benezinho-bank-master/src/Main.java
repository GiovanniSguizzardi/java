import br.com.benezinhobank.model.Agencia;
import br.com.benezinhobank.model.Banco;
import br.com.benezinhobank.model.ContaCorrente;
import br.com.benezinhobank.model.ContaPoupanca;
import br.com.benezinhobank.pessoa.model.Pessoa;
import br.com.benezinhobank.pessoa.model.PessoaFisica;
import br.com.benezinhobank.pessoa.model.PessoaJuridica;

import javax.swing.*;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {

        Banco benezinho = new Banco("Gibas Bank");
        Agencia osasco = new Agencia();
        osasco.setBanco(benezinho);
        osasco.setNome("Osasco");
        osasco.setNumero("1-9");

        PessoaFisica mae = new PessoaFisica();
        mae.setCPF("073095398-00");
        mae.setNome("Debora");
        mae.setNascimento(LocalDate.of(1985,5,16));

        PessoaFisica giovanni = new PessoaFisica();
        giovanni.setCPF("432516558-41");
        giovanni.setNascimento(LocalDate.of(2005,5,24));
        giovanni.setNome("Giovanni Sguizzardi Conde");
        giovanni.setMae(mae);

        PessoaFisica pedro = new PessoaFisica();
        pedro.setCPF("451269378-65");
        pedro.setNascimento(LocalDate.of(2004, 8, 19));
        pedro.setNome("Pedro Baraldi Sá");
        pedro.setMae(mae);

        ContaCorrente cc = new ContaCorrente();
        cc.setAgencia(osasco);
        cc.setTitular(giovanni);
        cc.setSaldo(1_000_00);
        cc.setLimite(5_000_00);
        cc.setNumero("1-9");

        ContaPoupanca cp = new ContaPoupanca();
        cp. setNumero ("2-8") ;
        cp. setAniversario(4);
        cp. setAgencia (osasco);
        cp. setSaldo (500_000);
        cp. setTitular (mae);

        PessoaJuridica holding = new PessoaJuridica();
        holding.setCNPJ("1231312/0001-09");
        holding.setNascimento (LocalDate.of(2005, 5, 24));
        holding.setNome ("Gibas Holding");
        holding.setRazaoSocial ("Gibas Holding SA");

        Pessoa[] socios = new Pessoa[3];
        socios[0] = giovanni;
        socios[1] = mae;
        socios[2] = pedro;
        holding.setSocios(socios);

        ContaCorrente ccH = new ContaCorrente ();
        ccH. setNumero ("3-7");
        ccH. setLimite (800_000_000);
        ccH. setSaldo (1_000_000_000);
        ccH. setTitular (holding);
        ccH. setAgencia (osasco);

        for(int i=0; i < socios.length; i++) {
            System.out.println(socios[i]);
        }

        int continua = 0;
        System.out.println("-==-==-==-==-==-==-==-==-==-==-==-==-==-==-");
        System.out.println("[*] Saldo inicial: " + ccH.getSaldo());
        System.out.println("[*] Limite: " + ccH.getLimite());
        System.out.println("[*] Saldo + Limite: " + (ccH.getSaldo() + ccH.getLimite()));
        System.out.println("-==-==-==-==-==-==-==-==-==-==-==-==-==-==-");

        do {

            double valor = Double.parseDouble((JOptionPane.showInputDialog("Informe o valor que deseja sacar")));

            boolean saquei = ccH.sacar(valor);

            if (saquei) {
                System.out.println("[-] Saque efetuado... | Saldo: " + ccH.getSaldo());
                System.out.println("-==-==-==-==-==-==-==-==-==-==-==-==-==-==-");
            } else {
                System.out.println("[!] Erro no saque!");
                System.out.println("-==-==-==-==-==-==-==-==-==-==-==-==-==-==-");
            }

            String texto = """                    
                    Deseja realizar um novo saque?
                                        
                    [ 1 ] SIM
                    [ 2 ] NÃO
                    
                    """;

            continua = Integer.parseInt(JOptionPane.showInputDialog(texto));

        } while (continua == 1);

        System.out.println("[$] Saldo atual: " + ccH.getSaldo());
    }
}