import br.com.benezinhobank.model.Agencia;
import br.com.benezinhobank.model.Banco;
import br.com.benezinhobank.model.ContaCorrente;
import br.com.benezinhobank.model.ContaPoupanca;
import br.com.benezinhobank.pessoa.model.Pessoa;
import br.com.benezinhobank.pessoa.model.PessoaFisica;
import br.com.benezinhobank.pessoa.model.PessoaJuridica;

import javax.swing.*;
import java.time.LocalDate;
import java.time.MonthDay;

public class Main {

    public static Agencia novaAgencia(String nome, Banco banco) {
        Agencia agencia = new Agencia();
        agencia.setNome(nome);
        banco.addAgencia(agencia);
        return agencia;
    }

    public static PessoaFisica novaPessoa(String nome, LocalDate nascimento, String CPF, PessoaFisica mae) {
        PessoaFisica pf = new PessoaFisica();
        pf.setCPF(CPF);
        pf.setNascimento(nascimento);
        pf.setNome(nome);
        pf.setMae(mae);
        return pf;
    }

    public static ContaCorrente novaContaCorrente(Agencia agencia, Pessoa titular, double limite) {
        ContaCorrente cc = new ContaCorrente();
        cc.setAgencia(agencia);
        cc.setTitular(titular);
        cc.setLimite(limite);
        agencia.addConta(cc);
        return cc;
    }

    public static ContaPoupanca novaContaPoupanca(Agencia agencia, Pessoa titular, MonthDay dia) {
        ContaPoupanca cp = new ContaPoupanca();
        cp.setAniversario(dia.getDayOfMonth());
        cp.setAgencia(agencia);
        cp.setTitular(titular);
        agencia.addConta(cp);
        return cp;
    }

    public static PessoaJuridica novaPessoaJuridica(String nomeFantasia, String razaoSocial, String CNPJ, LocalDate fundacao) {
        PessoaJuridica pj = new PessoaJuridica();
        pj.setCNPJ(CNPJ);
        pj.setNascimento(fundacao);
        pj.setNome(nomeFantasia);
        pj.setRazaoSocial(razaoSocial);
        return pj;
    }

    public static void main(String[] args) {
        Banco Gibas = new Banco("Gibas Bank");
        Agencia SaoPaulo = novaAgencia("SãoPaulo", Gibas);
        PessoaFisica mae = novaPessoa("Debora", LocalDate.of(1965, 5, 18), "073095398-00", null);
        PessoaFisica giovanni = novaPessoa("Giovanni Sguizzardi", LocalDate.of(2005, 5, 18), "432516558-41", mae);
        ContaCorrente cc = novaContaCorrente(SaoPaulo, giovanni, 2000);
        ContaPoupanca cp = novaContaPoupanca(SaoPaulo, mae, MonthDay.now());

        PessoaJuridica holding = novaPessoaJuridica(
                "Gibas Holding",
                "Gibas Holding SA",
                "1231312/0001-09",
                LocalDate.of(1988, 10, 5)
        );

        PessoaFisica lucca = novaPessoa(
                "Lucca",
                LocalDate.of(2004, 8, 19),
                "132132132132", mae);

        holding.addSocio(giovanni).addSocio(mae).addSocio(lucca);

        ContaCorrente ccH = novaContaCorrente(SaoPaulo, holding, 500);

        int continua;
        System.out.println("-==-==-==-==-==-==-==-");
        System.out.println("[$] Mudanca no saldo: " + ccH.getSaldo() + " R$");
        System.out.println("[$] Limite: " + ccH.getLimite() + " R$");
        System.out.println("[*] Disponivel: " + (ccH.getSaldo() + ccH.getLimite() + " R$"));
        System.out.println("-==-==-==-==-==-==-==-\n");

        do {
            double valor = Double.parseDouble(JOptionPane.showInputDialog("Informe o valor que deseja sacar"));
            boolean saquei = ccH.sacar(valor);

            if (saquei) {
                System.out.println("[!] Saque efetuado com sucesso!");
            } else {
                System.out.println("Erro no saque");
            }

            String texto = """
                    [?] Realizar um novo saque?
                    
                    [1] SIM
                    [2] NÃO
                    
                    """;
            continua = Integer.parseInt(JOptionPane.showInputDialog(texto));

        } while (continua == 1);

        System.out.println("\n-==-==-==-==-==-==-==-");
        System.out.println("[$] Mudanca no saldo: " + ccH.getSaldo() + " R$");
        System.out.println("[$] Limite: " + ccH.getLimite() + " R$");
        System.out.println("[*] Disponivel: " + (ccH.getSaldo() + ccH.getLimite() + " R$"));
        System.out.println("-==-==-==-==-==-==-==-");

    }
}